---------------------------------------------------------------------------
-- Dashboard3 Widget for RC Helicopters
-- EdgeTX 2.11+
-- Created By Moshir Fakhoury (FlyWithMoshirRC)
-- Created On 22/10/2026
-- Last Modified On 22/10/2026
-- Version H - This is specifically for RC Helicopters
---------------------------------------------------------------------------

local name = "fltDashP3vh"

local ACCENT   = lcd.RGB(0, 210, 255)   -- bright cyan-blue glow color
local ACCENT_DIM = lcd.RGB(0, 90, 120)  -- dimmed accent for inactive icon segments
local PANEL_BG = lcd.RGB(10, 14, 18)    -- slightly light black
local GREEN    = GREEN
local RED      = RED
local CHAMFER  = 10   

---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------

local options = {
  { "GPS",       SOURCE, 0 },
  { "RSSI",    SOURCE, 0 },
  { "Rx Batt",   SOURCE, 0 },
  { "Capa",      SOURCE, 0 },
  { "Current",   SOURCE, 0 },
  { "RPM",   SOURCE, 0 },
  { "Cells / Max Capa", STRING, "6,5000" },
  { "ESC Temp",      SOURCE, 0 },
  { "Motor On",       SWITCH, 0 },
  { "ARM",      SWITCH, 0 }
}

---------------------------------------------------------------------------
-- IMAGE HELPERS
---------------------------------------------------------------------------
local bm = nil

local function pngFilename(imgName)
  if not imgName or imgName == "" then return nil end

  if not string.match(imgName, "%.png$") then
    imgName = imgName .. ".png"
  end

  return imgName
end

local function fileExists(path)
  local f = io.open(path, "r")

  if f then
    io.close(f)
    return true
  end

  return false
end

local function loadImage(imgName)
  bm = nil

  if not imgName or imgName == "" then return false end

  local filename = pngFilename(imgName)
  local path = "/IMAGES/" .. filename

  local ok, img = pcall(Bitmap.open, path)

  if ok and img then
    bm = img
    return true
  end

  return false
end

---------------------------------------------------------------------------
-- CREATE
---------------------------------------------------------------------------
local function create(zone, opts)

  local w = {zone = zone, options = opts or {} }

  local modelName = model.getInfo().name

  local imagePath = "/IMAGES/" .. modelName .. ".png"

  if fileExists(imagePath) then
    loadImage(modelName)
  end

  return w
end

---------------------------------------------------------------------------
-- UPDATE
---------------------------------------------------------------------------

local function update(widget, opts)
  widget.options = opts
end

---------------------------------------------------------------------------
-- HELPERS
---------------------------------------------------------------------------

  local function srcVal(opt, key)
    return (opt[key] ~= 0 and getValue(opt[key])) or 0
  end

  local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
  end

  local function getBatteryConfig(value)
    local cells, maxCapa = string.match(value or "", "^%s*(%d+)%s*,%s*(%d+)%s*$")
    cells = tonumber(cells) or 0
    maxCapa = tonumber(maxCapa) or 0
    return cells, maxCapa
  end

  -- Bordered panel box with angled (chamfered) corners, near-black fill, accent border
  local function drawPanel(x, y, w, h)
    local c = CHAMFER

    lcd.drawFilledRectangle(x + c, y, w - 2 * c, h, PANEL_BG)
    lcd.drawFilledRectangle(x, y + c, c, h - 2 * c, PANEL_BG)
    lcd.drawFilledRectangle(x + w - c, y + c, c, h - 2 * c, PANEL_BG)
   
    for i = 0, c - 1 do
      local run = c - i
      lcd.drawLine(x + c - run, y + i, x + c, y + i, SOLID, PANEL_BG)                       -- top-left
      lcd.drawLine(x + w - c, y + i, x + w - c + run, y + i, SOLID, PANEL_BG)                -- top-right
      lcd.drawLine(x + c - run, y + h - 1 - i, x + c, y + h - 1 - i, SOLID, PANEL_BG)         -- bottom-left
      lcd.drawLine(x + w - c, y + h - 1 - i, x + w - c + run, y + h - 1 - i, SOLID, PANEL_BG) -- bottom-right
    end

    -- Border: straight edges + diagonal corners
    lcd.drawLine(x + c, y, x + w - c, y, SOLID, ACCENT)
    lcd.drawLine(x + c, y + h - 1, x + w - c, y + h - 1, SOLID, ACCENT)
    lcd.drawLine(x, y + c, x, y + h - c, SOLID, ACCENT)
    lcd.drawLine(x + w - 1, y + c, x + w - 1, y + h - c, SOLID, ACCENT)
    lcd.drawLine(x, y + c, x + c, y, SOLID, ACCENT)
    lcd.drawLine(x + w - c, y, x + w - 1, y + c, SOLID, ACCENT)
    lcd.drawLine(x, y + h - c, x + c, y + h - 1, SOLID, ACCENT)
    lcd.drawLine(x + w - c, y + h - 1, x + w - 1, y + h - c, SOLID, ACCENT)
  end

  local function iconArrowUp(x, y, color)
    lcd.drawFilledTriangle(x + 6, y,x,y + 7,x + 12, y + 7,color)
    lcd.drawFilledRectangle(x + 4, y + 7, 5, 13,color)
  end

  local function iconArrowDown(x, y, color)
    lcd.drawFilledRectangle(x + 4, y, 5, 18,color)
    lcd.drawFilledTriangle(x,y + 13,x + 12, y + 13,x + 6,  y + 20,color)
  end
---------------------------------------------------------------------------
-- ICONS
---------------------------------------------------------------------------

local function iconSignalBars(x, y, level, color)
  for i = 1, 5 do
    local bh = i * 3
    local bx = x + (i - 1) * 5
    local by = y + (15 - bh)
    lcd.drawFilledRectangle(bx, by, 3, bh, (i <= level) and color or ACCENT_DIM)
  end
end

local function iconBattery(x, y, percent, signalPresent)
  lcd.drawRectangle(x, y + 3, 16, 35, ACCENT)
  lcd.drawFilledRectangle(x + 5, y, 6, 4, ACCENT)

  if signalPresent then
    local fillH = math.floor(31 * percent / 100)

    local fillColor = GREEN

    if percent < 20 then
      fillColor = RED
    elseif percent < 50 then
      fillColor = YELLOW
    end

    if fillH > 0 then
      lcd.drawFilledRectangle(x + 2, y + 5 + (31 - fillH), 12, fillH, fillColor)
    end

  end
end

local function iconSatellite(x, y)
  lcd.drawCircle(x + 6, y + 6, 5, ACCENT)
  lcd.drawLine(x + 6, y, x + 6, y - 4, SOLID, ACCENT)
  lcd.drawLine(x + 2, y + 10, x - 2, y + 14, SOLID, ACCENT)
end

local function iconClock(x, y)
  lcd.drawCircle(x + 7, y + 7, 7, ACCENT)
  lcd.drawLine(x + 7, y + 7, x + 7, y + 2, SOLID, ACCENT)
  lcd.drawLine(x + 7, y + 7, x + 11, y + 9, SOLID, ACCENT)
end

local function iconFan(x, y, spinning)
  local c = spinning and GREEN or ACCENT
  lcd.drawCircle(x + 7, y + 7, 7, c)
  lcd.drawLine(x + 7, y + 7, x + 7, y, SOLID, c)
  lcd.drawLine(x + 7, y + 7, x + 12, y + 10, SOLID, c)
  lcd.drawLine(x + 7, y + 7, x + 2, y + 10, SOLID, c)
end

local function iconArm(x, y, color)
  --lcd.drawArc(x + 8, y + 9, 6, 135, 405, color)
  lcd.drawCircle(x + 8, y + 9, 6, color)
  lcd.drawLine(x + 8, y, x + 8, y + 7, SOLID, color)
end

local function iconTemp(x, y, color)
  -- Thermometer outline
  lcd.drawLine(x + 5, y + 2, x + 5, y + 15, SOLID, color)
  lcd.drawLine(x + 9, y + 2, x + 9, y + 15, SOLID, color)
  lcd.drawLine(x + 5, y + 2, x + 9, y + 2, SOLID, color)

  -- Temperature bulb
  lcd.drawCircle(x + 7, y + 16, 4, color)
  lcd.drawLine(x + 7, y + 6, x + 7, y + 16, SOLID, color)

  -- Heat marks
  lcd.drawLine(x + 14, y + 5, x + 16, y + 2, SOLID, color)
  lcd.drawLine(x + 14, y + 11, x + 16, y + 8, SOLID, color)
end

local function iconCurrent(x, y)
  lcd.drawLine(x + 10, y,     x + 3,  y + 10, SOLID, ACCENT)
  lcd.drawLine(x + 3,  y + 10, x + 8,  y + 10, SOLID, ACCENT)
  lcd.drawLine(x + 8,  y + 10, x + 4,  y + 20, SOLID, ACCENT)
end

local function drawThrottlePanel(x, y, w, h)
  -- Line 1
  lcd.drawLine(x + w * 0.05, y + h * 0.94, x + w * 1.75, y + h * 0.94, SOLID, ACCENT)

  -- Line 2
  lcd.drawLine(x + w * 1.75, y + h * 0.94, x + w * 1.67, y + h * 0.70, SOLID, ACCENT)

  -- Line 3
  lcd.drawLine(x + w * 1.67, y + h * 0.70, x + w * 1.12, y + h * 0.70, SOLID, ACCENT)

  -- Line 4
  lcd.drawLine(x + w * 1.05, y + h * 0.94, x + w * 1.13, y + h * 0.70, SOLID, ACCENT)

  -- Line 5
  lcd.drawLine(x + w * 1.13, y + h * 0.70, x + w * 0.88, y + h * -0.10, SOLID, ACCENT)

  -- Line 6
  lcd.drawLine(x + w * 0.88, y + h * -0.10, x + w * 0.80, y + h * -0.10, SOLID, ACCENT)

  -- Line 7
  lcd.drawLine(x + w * 0.725, y + h * -0.325, x + w * 0.875, y + h * 0.125, SOLID, ACCENT)

  -- Line 8
  lcd.drawLine(x + w * 0.725, y + h * -0.325, x + w * 0.05, y + h * -0.325, SOLID, ACCENT)
 
  -- Line 9
  lcd.drawLine(x + w * 0.05, y + h * -0.325, x + w * 0.02, y + h * -0.05, SOLID, ACCENT)

  -- Line 10
  lcd.drawLine(x + w * 0.02, y + h * -0.05, x + w * 0.02, y + h * 0.72, SOLID, ACCENT)

  -- Line 11
  lcd.drawLine(x + w * 0.02, y + h * 0.72, x + w * 0.05, y + h * 0.94, SOLID, ACCENT)
end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------
local function refresh(widget)
  local z = widget.zone
  local opt = widget.options

-- Background
for i = 0, z.h - 1 do
  local t = i / z.h
  local r = math.floor(5 * (1 - t))
  local g = math.floor(30 * (1 - t))
  local b = math.floor(60 * (1 - t))
  lcd.drawFilledRectangle(z.x, z.y + i, z.w, 1, lcd.RGB(r, g, b))
end

  ---------------------------------------------------------------------------
  -- LAYOUT REGIONS
  ---------------------------------------------------------------------------
  local topH     = 52
  local leftW    = math.floor(z.w * 0.40)
  local rightW   = math.floor(z.w * 0.24)
  local gap      = 6
  local midW     = z.w - leftW - rightW - gap

  local topY     = z.y
  local bodyY    = z.y + topH + gap
  local bodyH    = z.h - topH - gap

  ---------------------------------------------------------------------------
  -- LEFT COLUMN: IMAGE
  ---------------------------------------------------------------------------
  local imgH = math.floor(bodyH * 0.75)
  
  if bm then
    local bw, bh = Bitmap.getSize(bm)

    local aw = leftW
    local ah = imgH

    local wr = aw / bw
    local hr = ah / bh

    local scl
    local dx = z.x
    local dy = bodyY

    if wr < hr then
      scl = math.floor(wr * 100)
      local scaledH = bh * wr
      dy = bodyY + (imgH - scaledH) / 2
    else
      scl = math.floor(hr * 100)
      local scaledW = bw * hr
      dx = z.x + (leftW - scaledW) / 2
    end

  lcd.drawBitmap(bm, dx, dy, scl)
  end  

  if not bm then
    lcd.drawText(z.x + leftW / 2,bodyY + imgH / 2,"IMAGE NOT FOUND",CENTER + SMLSIZE + ACCENT_DIM)
  end

  ---------------------------------------------------------------------------
  -- TOP BAR: MODEL NAME / RSSI / CURR / GPS
  ---------------------------------------------------------------------------
  drawPanel(z.x, topY, z.w, topH)

  lcd.drawText(z.x + 10, topY + 4, "Model", SMLSIZE + ACCENT)
  lcd.drawText(z.x + 10, topY + 18, model.getInfo().name or "MODEL", MIDSIZE + WHITE)

  local fm = getFlightMode() or 0
  lcd.drawText(z.x + leftW - 40, topY + 4, "BANK", SMLSIZE + ACCENT)
  lcd.drawText(z.x + leftW - 35, topY + 18, tostring(fm), MIDSIZE + WHITE)

  local rssiVal = srcVal(opt, "RSSI")
  local signalPresent = rssiVal ~= 0
  local rssiColor = ACCENT_DIM

  if rssiVal == 0 then
    rssiColor = ACCENT_DIM
  elseif rssiVal <= -66 then
    rssiColor = RED
  elseif rssiVal <= -41 then
    rssiColor = YELLOW
  else
    rssiColor = GREEN
  end

  local rxbVal  = srcVal(opt, "Rx Batt")
  local currentVal = srcVal(opt, "Current")
  local capaVal = srcVal(opt, "Capa")
  local cells   = getBatteryConfig(opt["Cells / Max Capa"], 1)
  local maxCapa = getBatteryConfig(opt["Cells / Max Capa"], 2)

  -- TX Battery warning colour + flash logic
  local txV = getValue("tx-voltage") or 0
  local txColor = GREEN
  local flash = false

  if txV <= 6.8 then
    txColor = RED
    flash = true
  elseif txV <= 7.4 then
    txColor = ORANGE
  end

  if flash and (getTime() % 20 < 10) then
    txColor = ACCENT_DIM
  end

  local capaPercent = 0
  if maxCapa > 0 then
    capaPercent = clamp((1 - (capaVal / maxCapa)) * 100, 0, 100)
  end

  local rxBattPercent = 0
  if cells > 0 then
    local cellVoltage = rxbVal / cells
    rxBattPercent = clamp((cellVoltage - 3.30) / (4.20 - 3.30) * 100, 0, 100)
  end

  local statW = math.floor((z.w - leftW - 20) / 3)
  local stat1X = z.x + leftW
  local stat2X = stat1X + statW
  local stat3X = stat2X + statW

  local rssiLevel = 0

  if signalPresent then
    if rssiVal >= -20 then
      rssiLevel = 5
    elseif rssiVal >= -40 then
      rssiLevel = 4
    elseif rssiVal >= -50 then
      rssiLevel = 3
    elseif rssiVal >= -65 then
      rssiLevel = 2
    else
      rssiLevel = 1
    end
  end

  iconSignalBars(stat1X + 15, topY + 8, rssiLevel, rssiColor)
  lcd.drawText(stat1X + 45, topY + 4, "RSSI", SMLSIZE + ACCENT)
  lcd.drawText(stat1X + 45, topY + 18, string.format("%d", rssiVal), MIDSIZE + rssiColor)

  iconCurrent(stat2X + 6, topY + 8)
  lcd.drawText(stat2X + 24, topY + 4, "Current", SMLSIZE + ACCENT)
  lcd.drawText(stat2X + 24, topY + 18, string.format("%.1fA", currentVal), MIDSIZE + WHITE)

  iconSatellite(stat3X + 30, topY + 10)
  lcd.drawText(stat3X + 50, topY + 4, "GPS", SMLSIZE + ACCENT)
  lcd.drawText(stat3X + 50, topY + 18, string.format("%d", srcVal(opt, "GPS")), MIDSIZE + WHITE)

  ---------------------------------------------------------------------------
  -- RPM DISPLAY
  ---------------------------------------------------------------------------

  local rpmPanelY = bodyY + imgH + gap
  local rpmPanelH = bodyH - imgH - gap

  drawThrottlePanel(z.x, rpmPanelY, leftW, rpmPanelH)

  local rpmVal = srcVal(opt, "RPM")
  local rpmY = rpmPanelY + rpmPanelH * -0.30

  local labelX = z.x + leftW * 0.50
  local valueX = labelX * 0.10

  lcd.drawText(valueX,rpmY + rpmPanelH * 0.15,string.format("%.0f", rpmVal),LEFT + DBLSIZE + WHITE)
  lcd.drawText(labelX,rpmY + rpmPanelH * 0.45,"RPM",SMLSIZE + ACCENT)
    
  ---------------------------------------------------------------------------
  -- MIDDLE COLUMN: RXBAT / CAPA / TIMER
  ---------------------------------------------------------------------------
  local midX = z.x + leftW + gap
    local midH = math.floor(bodyH * 0.85) 
    drawPanel(midX, bodyY, midW - gap, midH)

  local rowH = math.floor(midH / 3)

  local gpsVal = srcVal(opt, "GPS")
  local timer  = model.getTimer(0)
  local tSecs  = timer.value or 0

  iconBattery(midX + 12, bodyY + 10, rxBattPercent, signalPresent)
  lcd.drawText(midX + 40, bodyY + 8, "RxBat", SMLSIZE + ACCENT)
  lcd.drawText(midX + 40, bodyY + 20, string.format("%.1fV", rxbVal), MIDSIZE + WHITE)
  lcd.drawFilledCircle(midX + midW - 22, bodyY + 17, 7, txColor)

  lcd.drawLine(midX + 4, bodyY + rowH, midX + midW - gap - 4, bodyY + rowH, SOLID, ACCENT_DIM)

  iconBattery(midX + 12, bodyY + rowH + 10, capaPercent, signalPresent)
  lcd.drawText(midX + 40, bodyY + rowH + 8, "Capa", SMLSIZE + ACCENT)
  lcd.drawText(midX + 40, bodyY + rowH + 20, string.format("%d mAh", capaVal), MIDSIZE + WHITE)

  lcd.drawLine(midX + 4, bodyY + rowH * 2, midX + midW - gap - 4, bodyY + rowH * 2, SOLID, ACCENT_DIM)

  iconClock(midX + 12, bodyY + rowH * 2 + 12)
  lcd.drawText(midX + 40, bodyY + rowH * 2 + 8, "Timer", SMLSIZE + ACCENT)
  lcd.drawText(midX + 40, bodyY + rowH * 2 + 20, string.format("%02d:%02d", math.floor(tSecs / 60), tSecs % 60), MIDSIZE + WHITE)

  ---------------------------------------------------------------------------
  -- RIGHT COLUMN: MOTOR / LANDING GEAR / FLAPS
  ---------------------------------------------------------------------------
  local rightX = midX + midW - gap + gap
  local boxH = math.floor((bodyH - 2 * gap) / 3)

  -- Motor
  local motorY = bodyY
  drawPanel(rightX, motorY, rightW, boxH)
  local motorOn = opt["Motor On"] ~= 0 and getSwitchValue(opt["Motor On"]) == true
  iconFan(rightX + 10, motorY + 10, motorOn)
  lcd.drawText(rightX + 34, motorY + 8, "Motor", SMLSIZE + ACCENT)
  lcd.drawText(rightX + 34, motorY + 25, motorOn and "ON" or "OFF", MIDSIZE + (motorOn and GREEN or WHITE))

  -- ARM
  local armY = motorY + boxH + gap
  drawPanel(rightX, armY, rightW, boxH)
  
  local armSwitch = opt["ARM"] or 0
  local armOn = armSwitch ~= 0 and getSwitchValue(armSwitch) == true

  iconArm(rightX + 10, armY + 10, (armOn and GREEN or ACCENT))

  if armOn then
    iconArrowUp(rightX + 10, armY + 30, GREEN)
  else
    iconArrowDown(rightX + 10, armY + 30, RED)
  end

  lcd.drawText(rightX + 34, armY + 8, "ARM", SMLSIZE + ACCENT)
  lcd.drawText(rightX + 34, armY + 25, armOn and "ON" or "OFF", MIDSIZE + (armOn and GREEN or WHITE))

  -- ESC Temperature
  local escY = armY + boxH + gap
  drawPanel(rightX, escY, rightW, boxH)

  local escTemp = srcVal(opt, "ESC Temp")

  iconTemp(rightX + 10, escY + 10, ACCENT)

  lcd.drawText(rightX + 34, escY + 8, "ESC Temp", SMLSIZE + ACCENT)
  lcd.drawText(rightX + 34, escY + 25,string.format("%.0f°C", escTemp), MIDSIZE + WHITE)

  end

---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}